document.addEventListener('DOMContentLoaded', () => {
    const woodfish = document.getElementById('woodfish');
    const stick = document.getElementById('stick');
    const sound = document.getElementById('woodfish-sound');
    const scoreElement = document.getElementById('score');
    const hitsElement = document.getElementById('hits');
    
    let score = 0;
    let hitCount = 0;
    let totalHits = 0;

    const blessings = [
        "逢考必过",
        "学霸上身",
        "做啥啥对",
        "超神发挥",
        "好运爆棚"
    ];

    function createBubble(text, isScore = true) {
        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        
        // 随机选择气泡浮动方向
        const floatDirection = Math.random() < 0.5 ? 'float-left' : 'float-right';
        bubble.classList.add(floatDirection);
        
        bubble.textContent = isScore ? `+${text}积分` : text;
        
        // 将气泡定位到木鱼上方
        const woodfishRect = woodfish.getBoundingClientRect();
        bubble.style.left = `${woodfishRect.left + woodfishRect.width/2}px`;
        bubble.style.top = `${woodfishRect.top}px`;
        
        document.body.appendChild(bubble);
        
        // 动画结束后移除气泡
        setTimeout(() => {
            bubble.remove();
        }, 1000);
    }

    function updateScore(points) {
        score += points;
        scoreElement.textContent = `获得 ${score} 积分`;
    }

    function updateHits() {
        totalHits++;
        hitsElement.textContent = `今日敲击 ${totalHits} 棒`;
    }

    function hitWoodfish() {
        // 播放音效
        sound.currentTime = 0;
        sound.play();

        // 添加木鱼缩小动画
        woodfish.classList.add('shrink');
        setTimeout(() => woodfish.classList.remove('shrink'), 100);

        // 木鱼棒动画
        stick.classList.add('hit');
        setTimeout(() => stick.classList.remove('hit'), 100);

        // 更新总敲击次数
        updateHits();

        // 计数并检查是否获得奖励
        hitCount++;
        if (hitCount >= 5) {
            hitCount = 0;
            
            // 70%概率显示祝福语
            if (Math.random() < 0.7) {
                const randomBlessing = blessings[Math.floor(Math.random() * blessings.length)];
                createBubble(randomBlessing, false);
            } else {
                const bonus = Math.floor(Math.random() * 3) + 1;
                createBubble(bonus);
                updateScore(bonus);
            }
        } else {
            // 无奖励时显示"棒"
            createBubble("棒", false);
        }
    }

    woodfish.addEventListener('click', hitWoodfish);
    woodfish.addEventListener('touchstart', (e) => {
        e.preventDefault();
        hitWoodfish();
    });
});
